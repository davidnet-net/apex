extends Node
## Davidnet Community Games SDK bridge for Godot HTML5 exports.
##
## window.DavidnetSDK is injected into every uploaded index.html by the Davidnet backend - it is
## plain JavaScript and its functions return Promises, which GDScript can't await directly. This
## autoload bridges into it via Godot's JavaScriptBridge singleton (only present in the HTML5
## export), routing every call through one small JS helper and passing everything as JSON strings
## both ways, so the rest of the game only ever deals with normal Dictionary/Array values.
##
## See https://davidnet.net/help/community-games for the full SDK reference this wraps.

## Emitted after every call whose response carries a "rateLimit" field (i.e. everything except
## realtime.*), so any screen can show the current budget without polling.
signal rate_limit_updated(status: Dictionary)

## Realtime events - these fire on their own, not in response to one call_sdk() request, so they
## are forwarded here as signals instead of callbacks. See DavidnetSDK.realtime.* in the docs.
signal realtime_message(room: String, data: Variant, from: Dictionary)
signal realtime_presence(room: String, event: String, member: Dictionary)
signal realtime_state(room: String, key: String, value: Variant, from: Dictionary)
signal realtime_matched(queue: String, room: String, members: Array)
signal realtime_announcement(data: Variant, from: Dictionary)
signal realtime_disconnected
signal realtime_reconnected(rooms: Array)
signal realtime_error(code: String, message: String)

var _sdk_ready := false
var _last_rate_limit: Dictionary = {}


func _ready() -> void:
	if not OS.has_feature("web"):
		# Expected in the editor or a non-web export target - warn rather than fail silently, so
		# testing locally doesn't just look like every SDK call silently did nothing.
		push_warning("DavidnetSDK: not running in the HTML5 export - SDK calls will be no-ops.")
		return

	JavaScriptBridge.eval(
		"""
		window.__dnCall = function(method, argsJson, onResolve, onReject) {
			var args = JSON.parse(argsJson);
			var path = method.split(".");
			var target = window.DavidnetSDK;
			for (var i = 0; i < path.length - 1; i++) target = target[path[i]];
			var fn = target[path[path.length - 1]];
			Promise.resolve(fn.apply(target, args)).then(function(result) {
				onResolve(JSON.stringify(result === undefined ? null : result));
			}).catch(function(err) {
				onReject(String(err && err.message ? err.message : err));
			});
		};

		window.__dnForward = function(forwardCb) {
			function fwd(eventName) {
				return function(data) {
					forwardCb(JSON.stringify({ event: eventName, data: data }));
				};
			}
			var rt = window.DavidnetSDK.realtime;
			rt.onMessage(fwd("message"));
			rt.onPresence(fwd("presence"));
			rt.onState(fwd("state"));
			rt.onMatched(fwd("matched"));
			rt.onAnnouncement(fwd("announcement"));
			rt.onDisconnect(function() { forwardCb(JSON.stringify({ event: "disconnect" })); });
			rt.onReconnect(fwd("reconnect"));
			rt.onError(fwd("error"));
		};
		""",
		true
	)

	var forward_cb := JavaScriptBridge.create_callback(_on_realtime_event)
	JavaScriptBridge.get_interface("window").__dnForward(forward_cb)

	_sdk_ready = true


func _on_realtime_event(cb_args: Array) -> void:
	var payload: Dictionary = JSON.parse_string(cb_args[0])
	var event_name: String = payload.get("event", "")
	var data = payload.get("data")

	match event_name:
		"message":
			realtime_message.emit(data.get("room"), data.get("data"), data.get("from", {}))
		"presence":
			realtime_presence.emit(data.get("room"), data.get("event"), data.get("member", {}))
		"state":
			realtime_state.emit(data.get("room"), data.get("key"), data.get("value"), data.get("from", {}))
		"matched":
			realtime_matched.emit(data.get("queue"), data.get("room"), data.get("members", []))
		"announcement":
			realtime_announcement.emit(data.get("data"), data.get("from", {}))
		"disconnect":
			realtime_disconnected.emit()
		"reconnect":
			realtime_reconnected.emit(data.get("rooms", []))
		"error":
			realtime_error.emit(data.get("code", ""), data.get("message", ""))


## Low-level entry point: calls any window.DavidnetSDK method. Use a dot-path for nested ones,
## e.g. "realtime.send". on_success receives a parsed Dictionary/Array/primitive (or null),
## on_error receives an error message String. Either callback may be a no-op lambda if you don't
## care (e.g. `func(_r): pass`), but you should always handle on_error in real game code.
func call_sdk(method: String, args: Array, on_success: Callable, on_error: Callable) -> void:
	if not _sdk_ready:
		push_warning("DavidnetSDK: call_sdk(\"%s\") ignored - not running in the HTML5 export." % method)
		on_error.call("DavidnetSDK is only available in the HTML5 export")
		return

	var resolve_cb := JavaScriptBridge.create_callback(func(cb_args: Array):
		var result = JSON.parse_string(cb_args[0])
		if result is Dictionary and result.has("rateLimit"):
			_last_rate_limit = result["rateLimit"]
			rate_limit_updated.emit(_last_rate_limit)
		on_success.call(result)
	)
	var reject_cb := JavaScriptBridge.create_callback(func(cb_args: Array):
		if String(cb_args[0]) == "RATELIMIT":
			_last_rate_limit["remaining"] = 0
			rate_limit_updated.emit(_last_rate_limit)
		on_error.call(cb_args[0])
	)

	var window_obj := JavaScriptBridge.get_interface("window")
	window_obj.__dnCall(method, JSON.stringify(args), resolve_cb, reject_cb)


## Last-known rate limit status ({ limit, remaining, resetAt }), updated after every call above
## (except realtime.*, which has its own separate 200 msg/s limit). Empty until the first call
## resolves. No network call - just the cached value from the most recent response.
func get_rate_limit_status() -> Dictionary:
	return _last_rate_limit


# --- Highscores & leaderboards ---


func apply_highscore(score: int, category: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("applyHighscore", [score, { "category": category }], on_success, on_error)


func get_highscores(category: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("getHighscores", [{ "category": category }], on_success, on_error)


# --- Save data ---


func save_json_blob(data: Dictionary, slot: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("saveJsonBlob", [data, { "slot": slot }], on_success, on_error)


func get_json_blob(slot: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("getJsonBlob", [{ "slot": slot }], on_success, on_error)


# --- Achievements ---


func unlock_achievement(
	id: String,
	display_name: String,
	description: String,
	icon: String,
	progress,
	target,
	on_success: Callable,
	on_error: Callable
) -> void:
	var achievement := {
		"id": id,
		"name": display_name,
		"description": description,
		"icon": icon,
		"progress": progress,
		"target": target
	}
	call_sdk("unlockAchievement", [achievement], on_success, on_error)


func get_achievements(on_success: Callable, on_error: Callable) -> void:
	call_sdk("getAchievements", [], on_success, on_error)


# --- Community levels (UGC) ---


func ugc_publish_level(id, title: String, data: Dictionary, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugcPublishLevel", [{ "id": id, "title": title, "data": data }], on_success, on_error)


func ugc_list_levels(mine: bool, limit: int, offset: int, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugcListLevels", [{ "mine": mine, "limit": limit, "offset": offset }], on_success, on_error)


func ugc_get_level(id: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugcGetLevel", [id], on_success, on_error)


func ugc_delete_level(id: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugcDeleteLevel", [id], on_success, on_error)


# --- Realtime multiplayer ---
# Listen for incoming events via the realtime_* signals above, not callbacks.


func realtime_join_room(room: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtimeJoinRoom", [room], on_success, on_error)


func realtime_leave_room(room: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtimeLeaveRoom", [room], on_success, on_error)


func realtime_get_room_info(room: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtimeRoomInfo", [room], on_success, on_error)


func realtime_send(room: String, data: Variant, echo: bool = false) -> void:
	call_sdk("realtimeSend", [room, data, { "echo": echo }], func(_r): pass, func(_e): pass)


func realtime_set_state(room: String, key: String, value: Variant, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtimeSetState", [room, key, value], on_success, on_error)


func realtime_join_queue(
	queue: String, group_size: int, metadata: Variant, on_success: Callable, on_error: Callable
) -> void:
	call_sdk("realtimeJoinQueue", [queue, group_size, metadata], on_success, on_error)


func realtime_leave_queue(queue: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtimeLeaveQueue", [queue], on_success, on_error)


func realtime_get_queue_info(queue: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtimeQueueInfo", [queue], on_success, on_error)


func realtime_announce(data: Variant, echo: bool = false) -> void:
	call_sdk("realtimeAnnounce", [data, { "echo": echo }], func(_r): pass, func(_e): pass)
