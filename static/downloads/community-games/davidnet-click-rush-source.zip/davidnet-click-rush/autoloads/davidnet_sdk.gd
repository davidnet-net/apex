extends Node
## Davidnet Community Games SDK bridge for Godot HTML5 exports.
##
## window.DavidnetSDK is injected into every uploaded index.html by the Davidnet backend - it is
## plain JavaScript and its functions return Promises, which GDScript can't await directly. This
## autoload bridges into it via Godot's JavaScriptBridge singleton (only present in the HTML5
## export), routing every call through one small JS helper and passing everything as JSON strings
## both ways, so the rest of the game only ever deals with normal Dictionary/Array values.
##
## See https://davidnet.net/help/community-games for the full SDK reference this wraps.

## Emitted once the bridge is actually safe to call (see _ready()'s comment on why "_sdk_ready
## is true" isn't immediate). Nothing needs to connect to this directly - call_sdk() already
## awaits it for you - but it's here if a screen wants to know when without making a call.
signal sdk_ready

## Emitted after every call whose response carries a "rateLimit" field (i.e. everything except
## realtime.*), so any screen can show the current budget without polling.
signal rate_limit_updated(status: Dictionary)

## Realtime events - these fire on their own, not in response to one call_sdk() request, so they
## are forwarded here as signals instead of callbacks. See DavidnetSDK.realtime.* in the docs.
signal realtime_message(room: String, data: Variant, from: Dictionary)
signal realtime_presence(room: String, event: String, member: Dictionary)
signal realtime_state(room: String, key: String, value: Variant, from: Dictionary)
signal realtime_matched(queue: String, room: String, members: Array)
signal realtime_announcement(data: Variant, from: Dictionary)
signal realtime_disconnected
signal realtime_reconnected(rooms: Array)
signal realtime_error(code: String, message: String)

var _web_capable := false
var _sdk_ready := false
var _last_rate_limit: Dictionary = {}


func _ready() -> void:
	_web_capable = OS.has_feature("web")
	if not _web_capable:
		# Expected in the editor or a non-web export target - warn rather than fail silently, so
		# testing locally doesn't just look like every SDK call silently did nothing.
		push_warning("DavidnetSDK: not running in the HTML5 export - SDK calls will be no-ops.")
		return

	JavaScriptBridge.eval(
		"""
		window.__dnCall = function(method, argsJson, onResolve, onReject) {
			var args = JSON.parse(argsJson);
			var path = method.split(".");
			var target = window.DavidnetSDK;
			for (var i = 0; i < path.length - 1; i++) target = target[path[i]];
			var fn = target[path[path.length - 1]];
			Promise.resolve(fn.apply(target, args)).then(function(result) {
				onResolve(JSON.stringify(result === undefined ? null : result));
			}).catch(function(err) {
				onReject(String(err && err.message ? err.message : err));
			});
		};

		window.__dnForward = function(forwardCb) {
			function fwd(eventName) {
				return function(data) {
					forwardCb(JSON.stringify({ event: eventName, data: data }));
				};
			}
			var rt = window.DavidnetSDK.realtime;
			rt.onMessage(fwd("message"));
			rt.onPresence(fwd("presence"));
			rt.onState(fwd("state"));
			rt.onMatched(fwd("matched"));
			rt.onAnnouncement(fwd("announcement"));
			rt.onDisconnect(function() { forwardCb(JSON.stringify({ event: "disconnect" })); });
			rt.onReconnect(fwd("reconnect"));
			rt.onError(fwd("error"));
		};
		""",
		true
	)

	var forward_cb := JavaScriptBridge.create_callback(_on_realtime_event)
	JavaScriptBridge.get_interface("window").__dnForward(forward_cb)

	# Calls fired synchronously this early - e.g. from another autoload's or the main scene's own
	# _ready() - can run before the browser has processed a single event-loop tick since this
	# script's JavaScriptBridge.eval()/create_callback() calls above. When that happens the JS
	# side's callback registration isn't actually wired up yet: __dnCall still runs and the real
	# window.DavidnetSDK method still gets called, but the resolve/reject callback silently never
	# fires - no error, the call just hangs forever. One process frame (a real rAF tick in the Web
	# export) plus a small margin reliably avoids that without every caller needing to know about it.
	await get_tree().process_frame
	await get_tree().create_timer(0.2).timeout

	_sdk_ready = true
	sdk_ready.emit()


func _on_realtime_event(cb_args: Array) -> void:
	var payload: Dictionary = JSON.parse_string(cb_args[0])
	var event_name: String = payload.get("event", "")
	var data = payload.get("data")

	match event_name:
		"message":
			realtime_message.emit(data.get("room"), data.get("data"), data.get("from", {}))
		"presence":
			realtime_presence.emit(data.get("room"), data.get("event"), data.get("member", {}))
		"state":
			realtime_state.emit(data.get("room"), data.get("key"), data.get("value"), data.get("from", {}))
		"matched":
			realtime_matched.emit(data.get("queue"), data.get("room"), data.get("members", []))
		"announcement":
			realtime_announcement.emit(data.get("data"), data.get("from", {}))
		"disconnect":
			realtime_disconnected.emit()
		"reconnect":
			realtime_reconnected.emit(data.get("rooms", []))
		"error":
			realtime_error.emit(data.get("code", ""), data.get("message", ""))


## Pending call_sdk() requests, drained one at a time by _drain_queue(). See call_sdk()'s comment
## for why this exists - it's not about pacing requests, it's a correctness fix.
var _call_queue: Array[Dictionary] = []
var _draining_queue := false


## Low-level entry point: calls any window.DavidnetSDK method. Use a dot-path for nested ones,
## e.g. "realtime.send". on_success receives a parsed Dictionary/Array/primitive (or null),
## on_error receives an error message String. Either callback may be a no-op lambda if you don't
## care (e.g. `func(_r): pass`), but you should always handle on_error in real game code.
##
## Calls are queued and dispatched ONE AT A TIME, waiting for each one's JS callback to actually
## fire before starting the next - not for pacing, but because several JavaScriptBridge.
## create_callback() calls created in the same engine tick don't reliably all get wired up; the
## ones that lose the race just silently never resolve (no error). That's invisible if you only
## ever fire one signed call at a time (which the per-session cooldown already forces), but it
## bites hard the moment more than one tab/screen kicks off its own read (getHighscores,
## getAchievements, getJsonBlob, ugc.listLevels, ...) from _ready() at the same time - which is
## normal and expected. Queueing here means every call site above stays simple and doesn't need
## to know any of this.
func call_sdk(method: String, args: Array, on_success: Callable, on_error: Callable) -> void:
	if not _web_capable:
		push_warning("DavidnetSDK: call_sdk(\"%s\") ignored - not running in the HTML5 export." % method)
		on_error.call("DavidnetSDK is only available in the HTML5 export")
		return

	_call_queue.append({
		"method": method, "args": args, "on_success": on_success, "on_error": on_error
	})
	if not _draining_queue:
		_drain_queue()


func _drain_queue() -> void:
	_draining_queue = true

	while not _call_queue.is_empty():
		# The bridge is still warming up (see the comment in _ready()) - wait for it instead of
		# dropping or failing the call. This is what makes it safe to call DavidnetSDK methods
		# from a tab's own _ready(), straight away, without every caller needing a manual delay.
		if not _sdk_ready:
			await sdk_ready

		var request: Dictionary = _call_queue.pop_front()
		await _dispatch_call(request.method, request.args, request.on_success, request.on_error)

	_draining_queue = false


func _dispatch_call(method: String, args: Array, on_success: Callable, on_error: Callable) -> void:
	var settled := false

	var resolve_cb := JavaScriptBridge.create_callback(func(cb_args: Array):
		settled = true
		var result = JSON.parse_string(cb_args[0])
		if result is Dictionary and result.has("rateLimit"):
			_last_rate_limit = result["rateLimit"]
			rate_limit_updated.emit(_last_rate_limit)
		on_success.call(result)
	)
	var reject_cb := JavaScriptBridge.create_callback(func(cb_args: Array):
		settled = true
		if String(cb_args[0]) == "RATELIMIT":
			_last_rate_limit["remaining"] = 0
			rate_limit_updated.emit(_last_rate_limit)
		on_error.call(cb_args[0])
	)

	var window_obj := JavaScriptBridge.get_interface("window")
	window_obj.__dnCall(method, JSON.stringify(args), resolve_cb, reject_cb)

	# Cap how long we'll block the queue on one call - the SDK's own functions already reject
	# after a 10s timeout, so 11s here is just a safety net in case a callback is somehow lost
	# entirely (e.g. the exact bug this queue exists to avoid, if it ever happens anyway).
	var waited := 0.0
	while not settled and waited < 11.0:
		await get_tree().process_frame
		waited += get_process_delta_time()

	if not settled:
		push_warning("DavidnetSDK: call_sdk(\"%s\") never got a response - giving up." % method)
		on_error.call("No response from DavidnetSDK")


## Last-known rate limit status ({ limit, remaining, resetAt }), updated after every call above
## (except realtime.*, which has its own separate 200 msg/s limit). Empty until the first call
## resolves. No network call - just the cached value from the most recent response.
func get_rate_limit_status() -> Dictionary:
	return _last_rate_limit


# --- Highscores & leaderboards ---


func apply_highscore(score: int, category: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("applyHighscore", [score, { "category": category }], on_success, on_error)


func get_highscores(category: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("getHighscores", [{ "category": category }], on_success, on_error)


# --- Save data ---


func save_json_blob(data: Dictionary, slot: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("saveJsonBlob", [data, { "slot": slot }], on_success, on_error)


func get_json_blob(slot: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("getJsonBlob", [{ "slot": slot }], on_success, on_error)


# --- Achievements ---


func unlock_achievement(
	id: String,
	display_name: String,
	description: String,
	icon: String,
	progress,
	target,
	on_success: Callable,
	on_error: Callable
) -> void:
	var achievement := {
		"id": id,
		"name": display_name,
		"description": description,
		"icon": icon,
		"progress": progress,
		"target": target
	}
	call_sdk("unlockAchievement", [achievement], on_success, on_error)


func get_achievements(on_success: Callable, on_error: Callable) -> void:
	call_sdk("getAchievements", [], on_success, on_error)


# --- Community levels (UGC) ---


func ugc_publish_level(id, title: String, data: Dictionary, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugc.publishLevel", [{ "id": id, "title": title, "data": data }], on_success, on_error)


func ugc_list_levels(mine: bool, limit: int, offset: int, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugc.listLevels", [{ "mine": mine, "limit": limit, "offset": offset }], on_success, on_error)


func ugc_get_level(id: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugc.getLevel", [id], on_success, on_error)


func ugc_delete_level(id: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugc.deleteLevel", [id], on_success, on_error)


# --- Realtime multiplayer ---
# Listen for incoming events via the realtime_* signals above, not callbacks.


func realtime_join_room(room: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.joinRoom", [room], on_success, on_error)


func realtime_leave_room(room: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.leaveRoom", [room], on_success, on_error)


func realtime_get_room_info(room: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.getRoomInfo", [room], on_success, on_error)


func realtime_send(room: String, data: Variant, echo: bool = false) -> void:
	call_sdk("realtime.send", [room, data, { "echo": echo }], func(_r): pass, func(_e): pass)


func realtime_set_state(room: String, key: String, value: Variant, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.setState", [room, key, value], on_success, on_error)


func realtime_join_queue(
	queue: String, group_size: int, metadata: Variant, on_success: Callable, on_error: Callable
) -> void:
	call_sdk("realtime.joinQueue", [queue, group_size, metadata], on_success, on_error)


func realtime_leave_queue(queue: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.leaveQueue", [queue], on_success, on_error)


func realtime_get_queue_info(queue: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.getQueueInfo", [queue], on_success, on_error)


func realtime_announce(data: Variant, echo: bool = false) -> void:
	call_sdk("realtime.announce", [data, { "echo": echo }], func(_r): pass, func(_e): pass)
