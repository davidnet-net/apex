extends Node
## Davidnet Community Games SDK bridge for Godot HTML5 exports.
##
## window.DavidnetSDK is injected into every uploaded index.html by the Davidnet backend - it is
## plain JavaScript and its functions return Promises, which GDScript can't await directly. This
## autoload bridges into it via Godot's JavaScriptBridge singleton (only present in the HTML5
## export), routing every call through one small JS helper and passing everything as JSON strings
## both ways, so the rest of the game only ever deals with normal Dictionary/Array values.
##
## See https://davidnet.net/help/community-games for the full SDK reference this wraps.

## Emitted once the bridge is actually safe to call (see _ready()'s comment on why "_sdk_ready
## is true" isn't immediate). Nothing needs to connect to this directly - call_sdk() already
## awaits it for you - but it's here if a screen wants to know when without making a call.
signal sdk_ready

## Emitted after every call whose response carries a "rateLimit" field (i.e. everything except
## realtime.*), so any screen can show the current budget without polling.
signal rate_limit_updated(status: Dictionary)

## Realtime events - these fire on their own, not in response to one call_sdk() request, so they
## are forwarded here as signals instead of callbacks. See DavidnetSDK.realtime.* in the docs.
signal realtime_message(room: String, data: Variant, from: Dictionary)
signal realtime_presence(room: String, event: String, member: Dictionary)
signal realtime_state(room: String, key: String, value: Variant, from: Dictionary)
signal realtime_matched(queue: String, room: String, members: Array)
signal realtime_announcement(data: Variant, from: Dictionary)
signal realtime_disconnected
signal realtime_reconnected(rooms: Array)
signal realtime_error(code: String, message: String)

var _web_capable := false
var _sdk_ready := false
var _last_rate_limit: Dictionary = {}


func _ready() -> void:
	_web_capable = OS.has_feature("web")
	if not _web_capable:
		# Expected in the editor or a non-web export target - warn rather than fail silently, so
		# testing locally doesn't just look like every SDK call silently did nothing.
		push_warning("DavidnetSDK: not running in the HTML5 export - SDK calls will be no-ops.")
		return

	# Deliberately NOT using JavaScriptBridge.create_callback() for responses here. An earlier
	# version of this bridge did, and it turned out unreliable in practice: a call's resolve/
	# reject callback could silently never fire even though the underlying HTTP request
	# genuinely succeeded - no error, the call just hung forever, seemingly regardless of
	# timing or how many calls were in flight. Polling via JavaScriptBridge.eval()'s return
	# value instead is slower in theory (one poll per process frame) but immune to that: eval()
	# is a plain synchronous call/return, nothing gets "wired up" that can silently fail to be.
	JavaScriptBridge.eval(
		"""
		window.__dnPending = {};

		window.__dnStart = function(method, argsJson, requestId) {
			var args = JSON.parse(argsJson);
			var path = method.split(".");
			var target = window.DavidnetSDK;
			for (var i = 0; i < path.length - 1; i++) target = target[path[i]];
			var fn = target[path[path.length - 1]];
			Promise.resolve(fn.apply(target, args)).then(function(result) {
				window.__dnPending[requestId] = {
					success: true,
					data: JSON.stringify(result === undefined ? null : result)
				};
			}).catch(function(err) {
				window.__dnPending[requestId] = {
					success: false,
					data: String(err && err.message ? err.message : err)
				};
			});
		};

		window.__dnPoll = function(requestId) {
			var entry = window.__dnPending[requestId];
			if (!entry) return "";
			delete window.__dnPending[requestId];
			return JSON.stringify(entry);
		};

		window.__dnRealtimeEvents = [];
		function __dnPush(eventName) {
			return function(data) {
				window.__dnRealtimeEvents.push({ event: eventName, data: data });
			};
		}
		var __dnRt = window.DavidnetSDK.realtime;
		__dnRt.onMessage(__dnPush("message"));
		__dnRt.onPresence(__dnPush("presence"));
		__dnRt.onState(__dnPush("state"));
		__dnRt.onMatched(__dnPush("matched"));
		__dnRt.onAnnouncement(__dnPush("announcement"));
		__dnRt.onDisconnect(function() { window.__dnRealtimeEvents.push({ event: "disconnect" }); });
		__dnRt.onReconnect(__dnPush("reconnect"));
		__dnRt.onError(__dnPush("error"));

		window.__dnPollRealtimeEvents = function() {
			if (window.__dnRealtimeEvents.length === 0) return "";
			var events = window.__dnRealtimeEvents;
			window.__dnRealtimeEvents = [];
			return JSON.stringify(events);
		};
		""",
		true
	)

	_sdk_ready = true
	sdk_ready.emit()


func _process(_delta: float) -> void:
	if not _sdk_ready:
		return

	var raw = JavaScriptBridge.eval("window.__dnPollRealtimeEvents()", true)
	if typeof(raw) != TYPE_STRING or raw == "":
		return

	var events: Array = JSON.parse_string(raw)
	for payload in events:
		_handle_realtime_event(payload)


func _handle_realtime_event(payload: Dictionary) -> void:
	var event_name: String = payload.get("event", "")
	var data = payload.get("data")

	match event_name:
		"message":
			realtime_message.emit(data.get("room"), data.get("data"), data.get("from", {}))
		"presence":
			realtime_presence.emit(data.get("room"), data.get("event"), data.get("member", {}))
		"state":
			realtime_state.emit(data.get("room"), data.get("key"), data.get("value"), data.get("from", {}))
		"matched":
			realtime_matched.emit(data.get("queue"), data.get("room"), data.get("members", []))
		"announcement":
			realtime_announcement.emit(data.get("data"), data.get("from", {}))
		"disconnect":
			realtime_disconnected.emit()
		"reconnect":
			realtime_reconnected.emit(data.get("rooms", []))
		"error":
			realtime_error.emit(data.get("code", ""), data.get("message", ""))


var _next_request_id := 0


## Low-level entry point: calls any window.DavidnetSDK method. Use a dot-path for nested ones,
## e.g. "realtime.send". on_success receives a parsed Dictionary/Array/primitive (or null),
## on_error receives an error message String. Either callback may be a no-op lambda if you don't
## care (e.g. `func(_r): pass`), but you should always handle on_error in real game code.
##
## Safe to call from anywhere, including straight from a node's own _ready() or several calls at
## once (each has its own request id and polls independently - no shared state between calls).
func call_sdk(method: String, args: Array, on_success: Callable, on_error: Callable) -> void:
	if not _web_capable:
		push_warning("DavidnetSDK: call_sdk(\"%s\") ignored - not running in the HTML5 export." % method)
		on_error.call("DavidnetSDK is only available in the HTML5 export")
		return

	if not _sdk_ready:
		await sdk_ready

	_next_request_id += 1
	var request_id := "r%d" % _next_request_id

	JavaScriptBridge.eval(
		"window.__dnStart(%s, %s, %s);" % [
			JSON.stringify(method), JSON.stringify(JSON.stringify(args)), JSON.stringify(request_id)
		],
		true
	)

	var poll_js := "window.__dnPoll(%s)" % JSON.stringify(request_id)
	var waited := 0.0
	while waited < 11.0:
		await get_tree().process_frame
		waited += get_process_delta_time()

		var raw = JavaScriptBridge.eval(poll_js, true)
		if typeof(raw) == TYPE_STRING and raw != "":
			var entry: Dictionary = JSON.parse_string(raw)
			if entry.get("success", false):
				var result = JSON.parse_string(entry.get("data", "null"))
				if result is Dictionary and result.has("rateLimit"):
					_last_rate_limit = result["rateLimit"]
					rate_limit_updated.emit(_last_rate_limit)
				on_success.call(result)
			else:
				var message: String = entry.get("data", "Unknown error")
				if message == "RATELIMIT":
					_last_rate_limit["remaining"] = 0
					rate_limit_updated.emit(_last_rate_limit)
				on_error.call(message)
			return

	push_warning("DavidnetSDK: call_sdk(\"%s\") never got a response - giving up." % method)
	on_error.call("No response from DavidnetSDK")


## Last-known rate limit status ({ limit, remaining, resetAt }), updated after every call above
## (except realtime.*, which has its own separate 200 msg/s limit). Empty until the first call
## resolves. No network call - just the cached value from the most recent response.
func get_rate_limit_status() -> Dictionary:
	return _last_rate_limit


# --- Highscores & leaderboards ---


func apply_highscore(score: int, category: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("applyHighscore", [score, { "category": category }], on_success, on_error)


func get_highscores(category: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("getHighscores", [{ "category": category }], on_success, on_error)


# --- Save data ---


func save_json_blob(data: Dictionary, slot: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("saveJsonBlob", [data, { "slot": slot }], on_success, on_error)


func get_json_blob(slot: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("getJsonBlob", [{ "slot": slot }], on_success, on_error)


# --- Achievements ---


func unlock_achievement(
	id: String,
	display_name: String,
	description: String,
	icon: String,
	progress,
	target,
	on_success: Callable,
	on_error: Callable
) -> void:
	var achievement := {
		"id": id,
		"name": display_name,
		"description": description,
		"icon": icon,
		"progress": progress,
		"target": target
	}
	call_sdk("unlockAchievement", [achievement], on_success, on_error)


func get_achievements(on_success: Callable, on_error: Callable) -> void:
	call_sdk("getAchievements", [], on_success, on_error)


# --- Community levels (UGC) ---


func ugc_publish_level(id, title: String, data: Dictionary, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugc.publishLevel", [{ "id": id, "title": title, "data": data }], on_success, on_error)


func ugc_list_levels(mine: bool, limit: int, offset: int, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugc.listLevels", [{ "mine": mine, "limit": limit, "offset": offset }], on_success, on_error)


func ugc_get_level(id: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugc.getLevel", [id], on_success, on_error)


func ugc_delete_level(id: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("ugc.deleteLevel", [id], on_success, on_error)


# --- Realtime multiplayer ---
# Listen for incoming events via the realtime_* signals above, not callbacks.


func realtime_join_room(room: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.joinRoom", [room], on_success, on_error)


func realtime_leave_room(room: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.leaveRoom", [room], on_success, on_error)


func realtime_get_room_info(room: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.getRoomInfo", [room], on_success, on_error)


func realtime_send(room: String, data: Variant, echo: bool = false) -> void:
	call_sdk("realtime.send", [room, data, { "echo": echo }], func(_r): pass, func(_e): pass)


func realtime_set_state(room: String, key: String, value: Variant, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.setState", [room, key, value], on_success, on_error)


func realtime_join_queue(
	queue: String, group_size: int, metadata: Variant, on_success: Callable, on_error: Callable
) -> void:
	call_sdk("realtime.joinQueue", [queue, group_size, metadata], on_success, on_error)


func realtime_leave_queue(queue: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.leaveQueue", [queue], on_success, on_error)


func realtime_get_queue_info(queue: String, on_success: Callable, on_error: Callable) -> void:
	call_sdk("realtime.getQueueInfo", [queue], on_success, on_error)


func realtime_announce(data: Variant, echo: bool = false) -> void:
	call_sdk("realtime.announce", [data, { "echo": echo }], func(_r): pass, func(_e): pass)
