# Davidnet Community Games SDK Example (Godot)

A small, complete Godot 4.6 game — **Click Rush** — built to exercise every feature of the
[Davidnet Community Games SDK](https://davidnet.net/help/community-games), using the
`JavaScriptBridge` bridge pattern documented at
[/help/community-games/godot](https://davidnet.net/help/community-games/godot).

The game itself is intentionally trivial (click a button as many times as possible before a timer
runs out) so that every tab below is wired to a real gameplay moment rather than being a bare API
tester.

## Project layout

- `autoloads/davidnet_sdk.gd` — the SDK bridge singleton (autoloaded as `DavidnetSDK`). This is the
  reusable part: everything else in the project just calls its typed wrapper methods
  (`apply_highscore`, `save_json_blob`, `realtime_send`, ...) or listens to its `realtime_*`
  signals. Copy this file into your own Godot project as a starting point.
- `scripts/main.gd` + `scenes/main.tscn` — root scene: a rate-limit status bar (updated from
  `DavidnetSDK.rate_limit_updated`) plus a tab per feature area. The whole UI is built
  procedurally in GDScript (no hand-authored `.tscn` node trees beyond the root), so there's
  nothing but code to read through.
- `scripts/tabs/play_tab.gd` — **Click Rush** itself. Demonstrates `getJsonBlob`/`saveJsonBlob`
  (a "profile" save slot with lifetime click count), `applyHighscore` (multiple categories: a
  default `"classic"` one plus a `"challenge-<id>"` one per published Challenge), and
  `unlockAchievement` both as a classic instant unlock (`first_click`, `quick_draw`) and as a
  progress-bar achievement (`click_master`, updated once per round — not every click, see the
  comment in `_on_round_over`).
- `scripts/tabs/leaderboard_tab.gd` — `getHighscores` for any category you type in.
- `scripts/tabs/achievements_tab.gd` — `getAchievements`, rendering progress bars and rarity
  percentages.
- `scripts/tabs/challenges_tab.gd` — community levels (`ugc.publishLevel`/`listLevels`/`getLevel`/
  `deleteLevel`), reimagined as player-published "Challenges": a custom round duration. Picking one
  calls back into `PlayTab.start_challenge()`.
- `scripts/tabs/multiplayer_tab.gd` — realtime: a shared `"lobby"` room (`joinRoom`/`leaveRoom`,
  `setState`/`onState` for live per-player status, `onPresence` for a join/leave log), 1v1
  matchmaking (`joinQueue`/`onMatched`), in-room messaging (`send`/`onMessage`), and a lobby-wide
  announce channel (`announce`/`onAnnouncement`) — also used automatically by Click Rush whenever
  you set a new world record.

## Running it

This project only talks to Davidnet once actually uploaded and played inside the sandboxed iframe —
`window.DavidnetSDK` doesn't exist anywhere else. Running it from the Godot editor or as a desktop
export is still useful for checking the UI and gameplay logic (every SDK call will warn and no-op,
see `DavidnetSDK._ready()`), but to see real data you need to export and upload it:

1. Open the project in Godot 4.6. **Use the standard (non-mono) build to export** - the project
   only uses GDScript, no C#, which is good because it has to be the non-mono build: Godot's
   official .NET/Mono export templates don't ship Web/HTML5 templates at all (checked directly
   against the 4.6.3 release assets - every other platform is there, Web isn't). `godot-mono` is
   fine for opening/editing the project, just not for the Web export step.
2. **Project > Export...**, add a **Web** preset if there isn't one already (you'll need the
   matching export templates installed via Editor > Manage Export Templates, from the non-mono
   build). In the preset's Options, leave **Thread Support OFF** - Davidnet's game server doesn't
   send the `Cross-Origin-Opener-Policy`/`Cross-Origin-Embedder-Policy` headers a threaded build
   needs (deliberately - see the Godot docs page, "Export settings that work"), so a threaded
   export fails with a "SharedArrayBuffer... missing" error instead of loading. This project
   already ships with `export_presets.cfg` configured correctly (`thread_support=false`) - if
   you're starting fresh from this as a template, just don't turn it on.
3. Name the export file **`index.html`** (not the project name) - whatever you type becomes the
   name of every generated file, and the zip you upload needs `index.html` at its root.
4. Export to a folder, then zip the contents so `index.html` is at the ROOT of the zip (not inside
   a subfolder - see the Troubleshooting page if the upload is rejected).
5. Upload the zip at [home.davidnet.net/games/community/upload](https://home.davidnet.net/games/community/upload).
   `window.DavidnetSDK` is injected automatically - nothing in this project needs to change between
   the exported files and what you upload.

## If you're starting your own game from this

Keep `autoloads/davidnet_sdk.gd` as-is and delete everything else - it's a complete, reusable
bridge. Read [/help/community-games](https://davidnet.net/help/community-games) for the full SDK
reference (every page has a "Copy this page for AI" button if you're pairing with an AI assistant),
or copy the "Copy full reference for AI" snippet from the docs index into your assistant's context
directly.
