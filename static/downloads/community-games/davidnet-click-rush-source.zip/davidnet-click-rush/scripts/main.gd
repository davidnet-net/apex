extends Control
## Root scene: a status bar showing the SDK's rate-limit budget (DavidnetSDK.rate_limit_updated),
## plus one tab per feature area of the Community Games SDK. See autoloads/davidnet_sdk.gd for the
## bridge every tab calls into, and https://davidnet.net/help/community-games for the full
## reference this project is a worked example of.

var _rate_limit_label: Label
var _play_tab: PlayTab


func _ready() -> void:
	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(root)

	var header := PanelContainer.new()
	root.add_child(header)

	var header_box := HBoxContainer.new()
	header_box.add_theme_constant_override("separation", 12)
	header.add_child(header_box)

	var title := Label.new()
	title.text = "Davidnet Community Games SDK Example — Click Rush"
	title.add_theme_font_size_override("font_size", 18)
	header_box.add_child(title)

	_rate_limit_label = Label.new()
	_rate_limit_label.text = "Rate limit: no calls made yet"
	header_box.add_child(_rate_limit_label)

	var tabs := TabContainer.new()
	tabs.set_anchors_preset(Control.PRESET_FULL_RECT)
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(tabs)

	_play_tab = PlayTab.new()
	_play_tab.name = "Click Rush"
	tabs.add_child(_play_tab)

	var leaderboard_tab := LeaderboardTab.new()
	leaderboard_tab.name = "Leaderboard"
	tabs.add_child(leaderboard_tab)

	var achievements_tab := AchievementsTab.new()
	achievements_tab.name = "Achievements"
	tabs.add_child(achievements_tab)

	var challenges_tab := ChallengesTab.new()
	challenges_tab.name = "Challenges"
	challenges_tab.challenge_selected.connect(_on_challenge_selected)
	tabs.add_child(challenges_tab)

	var multiplayer_tab := MultiplayerTab.new()
	multiplayer_tab.name = "Multiplayer"
	tabs.add_child(multiplayer_tab)

	DavidnetSDK.rate_limit_updated.connect(_on_rate_limit_updated)


func _on_challenge_selected(challenge_id: String, duration: float) -> void:
	_play_tab.start_challenge(challenge_id, duration)


func _on_rate_limit_updated(status: Dictionary) -> void:
	_rate_limit_label.text = "Rate limit: %s / %s remaining" % [
		str(status.get("remaining", "?")), str(status.get("limit", "?"))
	]
