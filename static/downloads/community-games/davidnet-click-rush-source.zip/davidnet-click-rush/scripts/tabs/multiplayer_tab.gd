extends Control
## Realtime multiplayer (DavidnetSDK.realtime.*): a shared lobby room (presence + setState/onState),
## 1v1 matchmaking (joinQueue/onMatched + send/onMessage), and a lobby-wide announce channel.
##
## Realtime listener events arrive as signals on the DavidnetSDK autoload (see its _on_realtime_event),
## not callbacks, because they fire on their own rather than in response to one specific call - this
## tab connects to those signals in _ready() and filters by room/queue name itself.
class_name MultiplayerTab

const LOBBY_ROOM := "lobby"
const DUEL_QUEUE := "duel"

# There's no "give me my own user id" SDK call - realtime state is just a game-defined key/value
# map per room, so a random local session id is a perfectly normal choice for ephemeral state like
# this (as opposed to persistent data like saves/highscores, which the server already ties to the
# real authenticated player regardless of what key you use here).
var _session_id := "player-%d" % randi()

var _in_lobby := false
var _duel_room: String = ""

var _lobby_status_input: LineEdit
var _lobby_members_container: VBoxContainer
var _lobby_log: Label
var _duel_status_label: Label
var _duel_log: Label
var _announce_log: Label
var _connection_label: Label

var _lobby_state: Dictionary = {}


func _ready() -> void:
	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 14)
	add_child(root)

	var title := Label.new()
	title.text = "Multiplayer"
	title.add_theme_font_size_override("font_size", 24)
	root.add_child(title)

	_connection_label = Label.new()
	_connection_label.text = "Connection: not yet used"
	root.add_child(_connection_label)

	root.add_child(_build_lobby_section())
	root.add_child(HSeparator.new())
	root.add_child(_build_duel_section())
	root.add_child(HSeparator.new())
	root.add_child(_build_announce_section())

	DavidnetSDK.realtime_presence.connect(_on_realtime_presence)
	DavidnetSDK.realtime_state.connect(_on_realtime_state)
	DavidnetSDK.realtime_matched.connect(_on_realtime_matched)
	DavidnetSDK.realtime_message.connect(_on_realtime_message)
	DavidnetSDK.realtime_announcement.connect(_on_realtime_announcement)
	DavidnetSDK.realtime_disconnected.connect(_on_realtime_disconnected)
	DavidnetSDK.realtime_reconnected.connect(_on_realtime_reconnected)
	DavidnetSDK.realtime_error.connect(_on_realtime_error)


func _build_lobby_section() -> VBoxContainer:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)

	var heading := Label.new()
	heading.text = "Lobby room"
	heading.add_theme_font_size_override("font_size", 18)
	box.add_child(heading)

	var hint := Label.new()
	hint.text = "Everyone who joins shares live status via setState/onState."
	box.add_child(hint)

	var join_row := HBoxContainer.new()
	join_row.add_theme_constant_override("separation", 8)
	box.add_child(join_row)

	var join_button := Button.new()
	join_button.text = "Join lobby"
	join_button.pressed.connect(_on_join_lobby_pressed)
	join_row.add_child(join_button)

	var leave_button := Button.new()
	leave_button.text = "Leave lobby"
	leave_button.pressed.connect(_on_leave_lobby_pressed)
	join_row.add_child(leave_button)

	var status_row := HBoxContainer.new()
	status_row.add_theme_constant_override("separation", 8)
	box.add_child(status_row)

	_lobby_status_input = LineEdit.new()
	_lobby_status_input.placeholder_text = "Your status (e.g. \"ready!\")"
	_lobby_status_input.custom_minimum_size = Vector2(220, 0)
	status_row.add_child(_lobby_status_input)

	var set_status_button := Button.new()
	set_status_button.text = "Update status"
	set_status_button.pressed.connect(_on_update_status_pressed)
	status_row.add_child(set_status_button)

	_lobby_members_container = VBoxContainer.new()
	box.add_child(_lobby_members_container)

	_lobby_log = Label.new()
	_lobby_log.autowrap_mode = TextServer.AUTOWRAP_WORD
	box.add_child(_lobby_log)

	return box


func _build_duel_section() -> VBoxContainer:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)

	var heading := Label.new()
	heading.text = "1v1 duel matchmaking"
	heading.add_theme_font_size_override("font_size", 18)
	box.add_child(heading)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	box.add_child(row)

	var find_button := Button.new()
	find_button.text = "Find duel"
	find_button.pressed.connect(_on_find_duel_pressed)
	row.add_child(find_button)

	var cancel_button := Button.new()
	cancel_button.text = "Cancel search"
	cancel_button.pressed.connect(_on_cancel_duel_pressed)
	row.add_child(cancel_button)

	var gg_button := Button.new()
	gg_button.text = "Send \"GG!\""
	gg_button.pressed.connect(_on_send_gg_pressed)
	row.add_child(gg_button)

	_duel_status_label = Label.new()
	_duel_status_label.text = "Not searching."
	box.add_child(_duel_status_label)

	_duel_log = Label.new()
	_duel_log.autowrap_mode = TextServer.AUTOWRAP_WORD
	box.add_child(_duel_log)

	return box


func _build_announce_section() -> VBoxContainer:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)

	var heading := Label.new()
	heading.text = "Lobby-wide announcements"
	heading.add_theme_font_size_override("font_size", 18)
	box.add_child(heading)

	var hint := Label.new()
	hint.text = "Goes to every connected player of this game, regardless of which room they're in (this is also used automatically by Click Rush when you set a new world record)."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	box.add_child(hint)

	var announce_button := Button.new()
	announce_button.text = "Announce \"Hello everyone!\""
	announce_button.pressed.connect(_on_announce_pressed)
	box.add_child(announce_button)

	_announce_log = Label.new()
	_announce_log.autowrap_mode = TextServer.AUTOWRAP_WORD
	box.add_child(_announce_log)

	return box


# --- Lobby ---


func _on_join_lobby_pressed() -> void:
	DavidnetSDK.realtime_join_room(LOBBY_ROOM, _on_lobby_joined, _on_lobby_join_error)


func _on_lobby_joined(result: Dictionary) -> void:
	_in_lobby = true
	_lobby_state = result.get("state", {})
	_render_lobby_members()
	_lobby_log.text = "Joined lobby with %d other member(s) already present." % (result.get("members", []) as Array).size()


func _on_lobby_join_error(message: String) -> void:
	_lobby_log.text = "Could not join lobby: %s" % message


func _on_leave_lobby_pressed() -> void:
	if not _in_lobby:
		return
	DavidnetSDK.realtime_leave_room(LOBBY_ROOM, _on_lobby_left, _on_lobby_leave_error)


func _on_lobby_left(_result: Dictionary) -> void:
	_in_lobby = false
	_lobby_state.clear()
	_render_lobby_members()
	_lobby_log.text = "Left the lobby."


func _on_lobby_leave_error(message: String) -> void:
	_lobby_log.text = "Could not leave lobby: %s" % message


func _on_update_status_pressed() -> void:
	if not _in_lobby:
		_lobby_log.text = "Join the lobby first."
		return
	var status := _lobby_status_input.text.strip_edges()
	DavidnetSDK.realtime_set_state(LOBBY_ROOM, _session_id, status, _on_status_updated, _on_status_update_error)


func _on_status_updated(_result: Dictionary) -> void:
	_lobby_state[_session_id] = _lobby_status_input.text.strip_edges()
	_render_lobby_members()


func _on_status_update_error(message: String) -> void:
	_lobby_log.text = "Could not update status: %s" % message


func _render_lobby_members() -> void:
	for child in _lobby_members_container.get_children():
		child.queue_free()

	if _lobby_state.is_empty():
		var empty := Label.new()
		empty.text = "(nobody has set a status yet)"
		_lobby_members_container.add_child(empty)
		return

	for key in _lobby_state.keys():
		var row_label := Label.new()
		var mine := " (you)" if key == _session_id else ""
		row_label.text = "%s%s: %s" % [key, mine, str(_lobby_state[key])]
		_lobby_members_container.add_child(row_label)


# --- Duel matchmaking ---


func _on_find_duel_pressed() -> void:
	_duel_status_label.text = "Searching for an opponent..."
	DavidnetSDK.realtime_join_queue(DUEL_QUEUE, 2, null, _on_duel_queue_joined, _on_duel_queue_error)


func _on_duel_queue_joined(_result: Dictionary) -> void:
	pass # onMatched (below) is what actually fires once an opponent is found


func _on_duel_queue_error(message: String) -> void:
	_duel_status_label.text = "Could not join matchmaking: %s" % message


func _on_cancel_duel_pressed() -> void:
	_duel_status_label.text = "Not searching."
	DavidnetSDK.realtime_leave_queue(DUEL_QUEUE, func(_r): pass, func(_e): pass)


func _on_send_gg_pressed() -> void:
	if _duel_room == "":
		_duel_log.text = "Find a duel first."
		return
	DavidnetSDK.realtime_send(_duel_room, { "text": "GG!" })
	_duel_log.text = "You: GG!"


# --- Realtime signal handlers (shared across every section above) ---


func _on_realtime_presence(room: String, event: String, member: Dictionary) -> void:
	if room != LOBBY_ROOM:
		return
	_lobby_log.text = "%s %s the lobby." % [member.get("displayName", "Someone"), "joined" if event == "join" else "left"]


func _on_realtime_state(room: String, key: String, value: Variant, _from: Dictionary) -> void:
	if room != LOBBY_ROOM:
		return
	_lobby_state[key] = value
	_render_lobby_members()


func _on_realtime_matched(queue: String, room: String, members: Array) -> void:
	if queue != DUEL_QUEUE:
		return
	_duel_room = room
	_duel_status_label.text = "Opponent found! (%d players in this duel)" % members.size()


func _on_realtime_message(room: String, data: Variant, from: Dictionary) -> void:
	if room != _duel_room:
		return
	_duel_log.text = "%s: %s" % [from.get("displayName", "Opponent"), str((data as Dictionary).get("text", data))]


func _on_realtime_announcement(data: Variant, from: Dictionary) -> void:
	var text = (data as Dictionary).get("text") if data is Dictionary and data.has("text") else str(data)
	_announce_log.text = "%s: %s" % [from.get("displayName", "Someone"), text]


func _on_realtime_disconnected() -> void:
	_connection_label.text = "Connection: reconnecting..."


func _on_realtime_reconnected(rooms: Array) -> void:
	_connection_label.text = "Connection: reconnected (%d room(s) rejoined)" % rooms.size()


func _on_realtime_error(code: String, message: String) -> void:
	_connection_label.text = "Connection error: %s (%s)" % [message, code]


func _on_announce_pressed() -> void:
	DavidnetSDK.realtime_announce({ "text": "Hello everyone!" })
	_announce_log.text = "You: Hello everyone!"
