extends Control
## Community levels (DavidnetSDK.ugc.*) reimagined as "Challenges": a player-published JSON blob
## describing a custom Click Rush round (just a duration, to keep the example focused on the SDK
## rather than level-editor UI). The platform never looks inside "data" - it's whatever format the
## game decides, here just { "durationSeconds": float }.
class_name ChallengesTab

## Emitted when the player picks a challenge to play - Main listens and forwards it to PlayTab,
## keeping the tabs decoupled from each other.
signal challenge_selected(challenge_id: String, duration: float)

var _title_input: LineEdit
var _duration_input: SpinBox
var _status_label: Label
var _rows_container: VBoxContainer
var _showing_mine := false


func _ready() -> void:
	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 10)
	add_child(root)

	var title := Label.new()
	title.text = "Challenges (community levels)"
	title.add_theme_font_size_override("font_size", 24)
	root.add_child(title)

	var hint := Label.new()
	hint.text = "Publish a custom round duration for others to play, or pick one from the list below."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(hint)

	var publish_row := HBoxContainer.new()
	publish_row.add_theme_constant_override("separation", 8)
	root.add_child(publish_row)

	_title_input = LineEdit.new()
	_title_input.placeholder_text = "Challenge name"
	_title_input.custom_minimum_size = Vector2(180, 0)
	publish_row.add_child(_title_input)

	_duration_input = SpinBox.new()
	_duration_input.min_value = 3
	_duration_input.max_value = 60
	_duration_input.value = 15
	_duration_input.suffix = "s"
	publish_row.add_child(_duration_input)

	var publish_button := Button.new()
	publish_button.text = "Publish"
	publish_button.pressed.connect(_on_publish_pressed)
	publish_row.add_child(publish_button)

	var list_row := HBoxContainer.new()
	list_row.add_theme_constant_override("separation", 8)
	root.add_child(list_row)

	var all_button := Button.new()
	all_button.text = "All challenges"
	all_button.pressed.connect(_on_show_all_pressed)
	list_row.add_child(all_button)

	var mine_button := Button.new()
	mine_button.text = "My challenges"
	mine_button.pressed.connect(_on_show_mine_pressed)
	list_row.add_child(mine_button)

	_status_label = Label.new()
	root.add_child(_status_label)

	_rows_container = VBoxContainer.new()
	root.add_child(_rows_container)

	_refresh()


func _on_publish_pressed() -> void:
	var title := _title_input.text.strip_edges()
	if title == "":
		title = "Untitled challenge"

	DavidnetSDK.ugc_publish_level(
		null, title, { "durationSeconds": _duration_input.value }, _on_published, _on_publish_error
	)


func _on_published(_result: Dictionary) -> void:
	_title_input.text = ""
	_status_label.text = "Challenge published!"
	_refresh()


func _on_publish_error(message: String) -> void:
	_status_label.text = "Could not publish challenge: %s" % message


func _on_show_all_pressed() -> void:
	_showing_mine = false
	_refresh()


func _on_show_mine_pressed() -> void:
	_showing_mine = true
	_refresh()


func _refresh() -> void:
	_status_label.text = "Loading..."
	DavidnetSDK.ugc_list_levels(_showing_mine, 20, 0, _on_list_loaded, _on_list_error)


func _on_list_loaded(result: Dictionary) -> void:
	for child in _rows_container.get_children():
		child.queue_free()

	var levels: Array = result.get("levels", [])
	if levels.is_empty():
		_status_label.text = "No challenges published yet - be the first!"
		return

	_status_label.text = ""
	for level in levels:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		_rows_container.add_child(row)

		var row_label := Label.new()
		row_label.text = "%s — by %s" % [level.get("title", "?"), level.get("creatorDisplayName", "?")]
		row_label.custom_minimum_size = Vector2(260, 0)
		row.add_child(row_label)

		var play_button := Button.new()
		play_button.text = "Play"
		play_button.pressed.connect(_on_play_pressed.bind(level.get("id")))
		row.add_child(play_button)

		if _showing_mine:
			var delete_button := Button.new()
			delete_button.text = "Delete"
			delete_button.pressed.connect(_on_delete_pressed.bind(level.get("id")))
			row.add_child(delete_button)


func _on_list_error(message: String) -> void:
	_status_label.text = "Could not list challenges: %s" % message


func _on_play_pressed(id: String) -> void:
	_status_label.text = "Loading challenge..."
	DavidnetSDK.ugc_get_level(id, _on_level_loaded, _on_level_error)


func _on_level_loaded(result: Dictionary) -> void:
	var data: Dictionary = result.get("data", {})
	var duration: float = float(data.get("durationSeconds", 10.0))
	_status_label.text = "Loaded \"%s\" - switch to Click Rush to play it." % result.get("title", "?")
	challenge_selected.emit(result.get("id", ""), duration)


func _on_level_error(message: String) -> void:
	_status_label.text = "Could not load challenge: %s" % message


func _on_delete_pressed(id: String) -> void:
	DavidnetSDK.ugc_delete_level(id, _on_deleted, _on_delete_error)


func _on_deleted(_result: Dictionary) -> void:
	_status_label.text = "Challenge deleted."
	_refresh()


func _on_delete_error(message: String) -> void:
	_status_label.text = "Could not delete challenge: %s" % message
