extends Control
## Shows DavidnetSDK.getHighscores() for any category - "classic" by default, but you can type in
## any category name, including the "challenge-<id>" ones PlayTab submits to when a Challenges-tab
## level is active. Demonstrates that categories are just strings the game makes up on the fly.
class_name LeaderboardTab

var _category_input: LineEdit
var _your_best_label: Label
var _global_best_label: Label
var _rows_container: VBoxContainer
var _status_label: Label


func _ready() -> void:
	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 10)
	add_child(root)

	var title := Label.new()
	title.text = "Leaderboard"
	title.add_theme_font_size_override("font_size", 24)
	root.add_child(title)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	root.add_child(row)

	var label := Label.new()
	label.text = "Category:"
	row.add_child(label)

	_category_input = LineEdit.new()
	_category_input.text = "classic"
	_category_input.custom_minimum_size = Vector2(200, 0)
	row.add_child(_category_input)

	var refresh_button := Button.new()
	refresh_button.text = "Refresh"
	refresh_button.pressed.connect(_on_refresh_pressed)
	row.add_child(refresh_button)

	_your_best_label = Label.new()
	_your_best_label.text = "Your best: -"
	root.add_child(_your_best_label)

	_global_best_label = Label.new()
	_global_best_label.text = "Global best: -"
	root.add_child(_global_best_label)

	_status_label = Label.new()
	root.add_child(_status_label)

	_rows_container = VBoxContainer.new()
	root.add_child(_rows_container)

	_on_refresh_pressed()


func _on_refresh_pressed() -> void:
	var category := _category_input.text.strip_edges()
	if category == "":
		category = "classic"
	_status_label.text = "Loading..."
	DavidnetSDK.get_highscores(category, _on_highscores_loaded, _on_highscores_error)


func _on_highscores_loaded(result: Dictionary) -> void:
	_status_label.text = ""

	var player_best = result.get("playerHighscore")
	_your_best_label.text = "Your best: %s" % (str(player_best) if player_best != null else "no score yet")

	var global_best = result.get("globalHighscore")
	if global_best != null:
		_global_best_label.text = "Global best: %d by %s" % [global_best.get("score", 0), global_best.get("displayName", "?")]
	else:
		_global_best_label.text = "Global best: nobody has scored yet"

	for child in _rows_container.get_children():
		child.queue_free()

	var leaderboard: Array = result.get("leaderboard", [])
	if leaderboard.is_empty():
		var empty := Label.new()
		empty.text = "No scores yet - be the first!"
		_rows_container.add_child(empty)
		return

	for entry in leaderboard:
		var row_label := Label.new()
		row_label.text = "#%d  %s — %d" % [entry.get("rank", 0), entry.get("displayName", "?"), entry.get("score", 0)]
		_rows_container.add_child(row_label)


func _on_highscores_error(message: String) -> void:
	_status_label.text = "Could not load leaderboard: %s" % message
