extends Control
## "Click Rush": click the button as many times as you can before the timer runs out. The whole
## point of this tab is to be a trivially simple game so that every SDK call below is wired to a
## real gameplay moment instead of a bare API tester.
class_name PlayTab

const ROUND_DURATION := 10.0
const CLICK_MASTER_TARGET := 1000

var _is_playing := false
var _clicks := 0
var _time_left := 0.0
var _lifetime_clicks := 0
var _best_round_score := 0
var _active_challenge_id: String = "" # set by ChallengesTab via start_challenge()
var _active_challenge_duration := ROUND_DURATION
var _pending_category := "classic"

var _click_button: Button
var _start_button: Button
var _timer_label: Label
var _clicks_label: Label
var _lifetime_label: Label
var _status_label: Label


func _ready() -> void:
	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 12)
	add_child(root)

	var title := Label.new()
	title.text = "Click Rush"
	title.add_theme_font_size_override("font_size", 24)
	root.add_child(title)

	var hint := Label.new()
	hint.text = "Click as many times as you can before the timer runs out."
	root.add_child(hint)

	_lifetime_label = Label.new()
	_lifetime_label.text = "Lifetime clicks: loading..."
	root.add_child(_lifetime_label)

	_timer_label = Label.new()
	_timer_label.text = "Time left: -"
	root.add_child(_timer_label)

	_clicks_label = Label.new()
	_clicks_label.text = "This round: 0"
	_clicks_label.add_theme_font_size_override("font_size", 20)
	root.add_child(_clicks_label)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	root.add_child(row)

	_start_button = Button.new()
	_start_button.text = "Start round"
	_start_button.pressed.connect(_on_start_pressed)
	row.add_child(_start_button)

	_click_button = Button.new()
	_click_button.text = "CLICK!"
	_click_button.disabled = true
	_click_button.custom_minimum_size = Vector2(160, 48)
	_click_button.pressed.connect(_on_click_pressed)
	row.add_child(_click_button)

	_status_label = Label.new()
	_status_label.text = ""
	_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(_status_label)

	DavidnetSDK.get_json_blob("profile", _on_profile_loaded, _on_profile_error)


## Called by ChallengesTab when the player starts a published challenge (a custom round
## duration). Submits to its own highscore category so each challenge gets its own leaderboard.
func start_challenge(challenge_id: String, duration: float) -> void:
	_active_challenge_id = challenge_id
	_active_challenge_duration = duration
	_status_label.text = "Challenge loaded (%ds round) - press Start round." % int(duration)


func _on_profile_loaded(result: Dictionary) -> void:
	var data = result.get("data")
	if data != null:
		_lifetime_clicks = int(data.get("lifetimeClicks", 0))
		_best_round_score = int(data.get("bestRoundScore", 0))
	_lifetime_label.text = "Lifetime clicks: %d (best round: %d)" % [_lifetime_clicks, _best_round_score]


func _on_profile_error(message: String) -> void:
	_lifetime_label.text = "Lifetime clicks: 0 (could not load save: %s)" % message


func _on_start_pressed() -> void:
	_is_playing = true
	_clicks = 0
	_time_left = _active_challenge_duration
	_clicks_label.text = "This round: 0"
	_start_button.disabled = true
	_click_button.disabled = false
	_status_label.text = ""


func _on_click_pressed() -> void:
	if not _is_playing:
		return

	_clicks += 1
	_lifetime_clicks += 1
	_clicks_label.text = "This round: %d" % _clicks

	# Instant achievement, unlocked exactly once - the moment the condition first becomes true,
	# not re-checked on every subsequent click.
	if _lifetime_clicks == 1:
		DavidnetSDK.unlock_achievement(
			"first_click", "Getting Started", "Click the button for the first time", "🖱️",
			null, null, func(_r): pass, func(_e): pass
		)


func _process(delta: float) -> void:
	if not _is_playing:
		return

	_time_left -= delta
	_timer_label.text = "Time left: %0.1fs" % max(_time_left, 0.0)

	if _time_left <= 0.0:
		_is_playing = false
		_click_button.disabled = true
		_start_button.disabled = false
		_on_round_over()


func _on_round_over() -> void:
	if _clicks > _best_round_score:
		_best_round_score = _clicks

	var category := "classic"
	if _active_challenge_id != "":
		category = "challenge-" + _active_challenge_id.substr(0, 40)
	_pending_category = category

	DavidnetSDK.save_json_blob(
		{ "lifetimeClicks": _lifetime_clicks, "bestRoundScore": _best_round_score },
		"profile",
		_on_profile_saved,
		_on_profile_save_error
	)

	DavidnetSDK.apply_highscore(_clicks, category, _on_highscore_submitted, _on_highscore_error)

	# Progress achievement - updated ONCE per round, not on every click, even though repeat calls
	# would be harmless no-ops server-side. See the Rate limits / Achievements docs.
	DavidnetSDK.unlock_achievement(
		"click_master", "Click Master", "Click %d times across all your rounds, ever" % CLICK_MASTER_TARGET,
		"🏆", _lifetime_clicks, CLICK_MASTER_TARGET,
		_on_click_master_result, func(_e): pass
	)

	if _clicks >= 20:
		DavidnetSDK.unlock_achievement(
			"quick_draw", "Quick Draw", "Click 20+ times in a single round", "⚡",
			null, null, func(_r): pass, func(_e): pass
		)


func _on_profile_saved(_result: Dictionary) -> void:
	_lifetime_label.text = "Lifetime clicks: %d (best round: %d)" % [_lifetime_clicks, _best_round_score]


func _on_profile_save_error(message: String) -> void:
	_status_label.text = "Could not save progress: %s" % message


func _on_highscore_submitted(result: Dictionary) -> void:
	var category := _pending_category
	if result.get("isNewGlobalBest", false):
		_status_label.text = "New world record on \"%s\": %d clicks!" % [category, _clicks]
		DavidnetSDK.realtime_announce({ "type": "new-record", "score": _clicks, "category": category })
	elif result.get("isNewPersonalBest", false):
		_status_label.text = "New personal best on \"%s\": %d clicks!" % [category, _clicks]
	else:
		_status_label.text = "Round over: %d clicks (best: %d)" % [_clicks, result.get("playerHighscore", _clicks)]


func _on_highscore_error(message: String) -> void:
	_status_label.text = "Could not submit score: %s" % message


func _on_click_master_result(result: Dictionary) -> void:
	if result.get("isNew", false):
		_status_label.text += "  Achievement unlocked: Click Master!"
