extends Control
## Shows DavidnetSDK.getAchievements() - both the instant ones (first_click, quick_draw) and the
## progress one (click_master) that PlayTab unlocks/advances.
class_name AchievementsTab

var _rows_container: VBoxContainer
var _status_label: Label


func _ready() -> void:
	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 10)
	add_child(root)

	var title := Label.new()
	title.text = "Achievements"
	title.add_theme_font_size_override("font_size", 24)
	root.add_child(title)

	var refresh_button := Button.new()
	refresh_button.text = "Refresh"
	refresh_button.pressed.connect(_on_refresh_pressed)
	root.add_child(refresh_button)

	_status_label = Label.new()
	root.add_child(_status_label)

	_rows_container = VBoxContainer.new()
	root.add_child(_rows_container)

	_on_refresh_pressed()


func _on_refresh_pressed() -> void:
	_status_label.text = "Loading..."
	DavidnetSDK.get_achievements(_on_achievements_loaded, _on_achievements_error)


func _on_achievements_loaded(result: Dictionary) -> void:
	for child in _rows_container.get_children():
		child.queue_free()

	var achievements: Array = result.get("achievements", [])
	if achievements.is_empty():
		_status_label.text = "No achievements yet - go play a round in Click Rush!"
		return

	_status_label.text = ""
	for a in achievements:
		var box := VBoxContainer.new()
		_rows_container.add_child(box)

		var done := a.get("unlockedAt") != null
		var header := Label.new()
		var icon: String = a.get("icon", "")
		header.text = "%s %s %s" % [icon, a.get("name", "?"), "(done)" if done else "(in progress)"]
		box.add_child(header)

		var desc := Label.new()
		desc.text = str(a.get("description", ""))
		box.add_child(desc)

		var target = a.get("target")
		if target != null:
			var bar := ProgressBar.new()
			bar.max_value = target
			bar.value = a.get("progress", 0)
			bar.show_percentage = false
			box.add_child(bar)

			var progress_label := Label.new()
			progress_label.text = "%d / %d  (%d%% of players have this)" % [
				a.get("progress", 0), target, a.get("unlockedPercentage", 0)
			]
			box.add_child(progress_label)
		else:
			var rarity_label := Label.new()
			rarity_label.text = "%d%% of players have this" % a.get("unlockedPercentage", 0)
			box.add_child(rarity_label)

		box.add_child(HSeparator.new())


func _on_achievements_error(message: String) -> void:
	_status_label.text = "Could not load achievements: %s" % message
